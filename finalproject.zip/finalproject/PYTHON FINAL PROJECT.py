'''
Cafe Program
Veronica Butters 
v2.0
DATE
'''

import tkinter as tk
from tkinter import *
from tkinter import ttk
root = Tk ()


def select (): #First window, users click whether they want hot coffee, ice coffee, or hot chocolate 
	global beverageSelection
	selectWindow = Toplevel ()
	selectWindow.title ('beverage slection')
	selectWindow.geometry ('400x150')
	
	
	beverageSelection = Selection(selectWindow, text = 'Please select which beverage you want : ',
						font =('Times', '18', 'bold')).pack()
	beverageSelection1 = Button(selectWindow, text = "hot chocolate", bg ='White', fg='Black',
																	font=('Times', '12', 'bold'), command = lambda: [hotChocolate(), selectWindow.destroy()])
	beverageSelection1.pack()
						
	beverageSelection2 = Button(selectWindow, text = "hot coffee", bg='White', fg='Black',
																	font=('Times', '12', 'bold'), command = lambda: [hotCoffee(), selectWindow.destroy()])
	beverageSelection2.pack()
						
	beverageSelection3 = Button(selectWindow, text = "ice coffee", bg='White', fg='Black',
                                                                        font=('Times', '12', 'bold'), command = lambda: [iceCoffee(), selectWindow.destroy()])
    #After the users choose one of the two options, it leads them to a second window 	

def hotChocolate(): #Window user clicks Hot Chocolate, the user chooses whether they want a small, medium, or large
        global hotchocolatelabel
        hotchocolateWindow = Toplevel()
        hotchocolateWindow.title ('Hot Chocolate Sizes') 
        hotchocolateWindow.geometry('400x150')
        
        hotchocolatelabel = Label (hotchocolateWindow, text = 'Please select a size :',
                            font=('Times', '18', 'bold',)).pack()
        hotChocolate1 = Button (hotchocolateWindow, text='small', bg ='White', fg='Black' ,
                                                  font=('Times', '12', 'bold'), command = lambda: [hotChocolatesmall(), hotchocolateWindow.destroy()])
        hotChocolate1.pack()
        
        hotChocolate2 = Button (hotchocolateWindow, text ='medium', bg='White', fg='Black', 
                                                  font=('Times', '12', 'bold',), command = lambda: [hotChocolatemedium(), hotchocolateWindow.destoryy()])
        hotChocolate2.pack()
        
        hotChocolate3 = Button (hotchocolateWindow, text = 'large', bg= 'White', fg ='Black',
                                                  font=('Times', '12', 'bold',), command = lambda: [hotChocolatelarge(), hotchocolateWindow.destroy()])                                         
        
    #After the user chooses a size, it showcases their prices
    
def hotChocolateprices (): #Window where the user clicks to purchase their Hot Chocolate based on the sizing of their beverage
   global hotchocolatelabel
   hotChocolateWindow = TopLevel()
   hotchocolateWindow.title ('Hot Chocolate Prices') 
   hotchocolateWindow.geometry('400x150')
   
   hotchocolatelabel = Label (hotchocolateWindow, text = 'Payment : ',
                        font=('Times', '18', 'bold',)).pack()
   hotChocolate1 = Button (hotchocolateWindow, text= "Hot Chocolate size: Small 6.99", bg='White', fg='Black',
                                font=('Times', '12', 'bold'), command = lambda: [end(), hotchocolateWindow.destroy()])
   hotChocolate1.pack()
    
   hotChocolate2 = Button (hotchocolateWindow, text = "Hot Chocolate size: Medium 7.49", bg = 'White', fg='Black',
                                font=('Times', '12', 'bold'), command = lambda: [end(), hotchocolateWindow.destroy()])
   hotChocolate2.pack()                            
    
   hotChocolate3 = Button (hotchocolateWindow, text = "Hot Chocolate size: Large 7.99", bg='Whote', fg='Black', 
                                font=('Times', '12', 'bold'), command = lambda: [end(), hotchocolateWindow.destroy()])
   hotChocolate3.pack()
    
    #After a user chooses their hot chocolate option and pays, they are taken to the end of the window and are given their beverage
   
def hotCoffee ():  #Window user clicks Hot Coffee, the user chooses whether they want a small, medium, or large
 global hotcoffeelabel
 hotcoffeeWindow = Toplevel()
 hotcoffeeWindow.title ('Hot Coffee Sizes') 
 hotcoffeeWindow.geometry('400x150')
        
 hotcoffeelabel = Label (hotcoffeeWindow, text = 'Please select a size :',
                            font=('Times', '18', 'bold',)).pack()
 hotCoffee1 = Button (hotcoffeeWindow, text='small', bg ='White', fg='Black', 
                            font=('Times', '12', 'bold'), command = lambda: [hotCoffeeesmall(), hotcoffeeWindow.destroy()])
 hotCoffee1.pack()
        
 hotCoffee2 = Button (hotcoffeeWindow, text ='medium', bg='White', fg='Black', 
                            font=('Times', '12', 'bold',), command = lambda: [hotCoffeeemedium(), hotcoffeeWindow.destoryy()])
 hotCoffee2.pack()
        
 hotCoffee3 = Button (hotcoffeeWindow, text = 'large', bg= 'White', fg ='Black',
                            font=('Times', '12', 'bold',), command = lambda: [hotCoffeelarge(), hotcoffeeWindow.destroy()])
    #After the user chooses a size, it showcases their prices.
    
def hotCoffeeeprices (): #Window where the user clicks to purchase their Hot Chocolate based on the sizing of their beverage
 global hotcoffeeelabel
 hotCoffeeWindow = TopLevel()
 hotcoffeeWindow.title ('Hot Coffee Prices') 
 hotcoffeeWindow.geometry('400x150')
   
 hotcoffeelabel = Label (hotcoffeeWindow, text = 'Payment : ',
                     font=('Times', '18', 'bold',)).pack()
 hotCoffee1 = Button (hotcoffeeWindow, text= "Hot Coffee size: Small 7.99", bg='White', fg='Black',
                           font=('Times', '12', 'bold'), command = lambda: [end(), hotcoffeeWindow.destroy()])
 hotCoffee1.pack()
    
 hotCoffee2 = Button (hotcoffeeWindow, text = "Hot Coffee size: Medium 8.49", bg = 'White', fg='Black', 
                            font=('Times', '12', 'bold'), command = lambda: [end(), hotcoffeeWindow.destroy()])
 hotCoffee2.pack()                            
    
 hotCoffee3 = Button (hotcoffeeWindow, text = "Hot Coffee size: Large 8.99", bg='Whote', fg='Black', 
                           font=('Times', '12', 'bold'), command = lambda: [end(), hotcoffeeWindow.destroy()])
 hotCoffee3.pack()
    
    #After a user chooses their hot coffee option and pays, they are taken to the end of the window and are given their beverage 
  
def iceCoffee ():  #Window user clicks Ice Coffee, the user chooses whether they want a small, medium, or large
 global icecoffeelabel
 icecoffeeWindow = Toplevel()
 icecoffeeWindow.title ('Ice Coffee Sizes') 
 icecoffeeWindow.geometry('400x150')
        
 icecoffeelabel = Label (icecoffeeWindow, text = 'Please select a size :',
                            font=('Times', '18', 'bold',)).pack()
 iceCoffee1 = Button (icecoffeeWindow, text='small', bg ='White', fg='Black', 
                                                  font=('Times', '12', 'bold'), command = lambda: [iceCoffeeesmall(), icecoffeeWindow.destroy()])
 iceCoffee1.pack()
        
 iceCoffee2 = Button (icecoffeeWindow, text ='medium', bg='White', fg='Black', 
                                                  font=('Times', '12', 'bold',), command = lambda: [iceCoffeeemedium(), icecoffeeWindow.destroy()])
 iceCoffee2.pack()
        
 iceCoffee3 = Button (icecoffeeWindow, text = 'large', bg= 'White', fg ='Black',
                                                  font=('Times', '12', 'bold',), command = lambda: [iceCoffeelarge(), icecoffeeWindow.destroy()])
    #After the user chooses a size, it showcases their prices
 
 def iceCoffeeprices (): #Window where the user clicks to purchase their Ice Coffee based on the sizing
  global icecoffeeelabel
 iceCoffeeWindow = TopLevel()
 icecoffeeWindow.title ('Ice Coffee Prices') 
 icecoffeeWindow.geometry('400x150')
   
 icecoffeelabel = Label (icecoffeeWindow, text = 'Payment : ',
                   font=('Times', '18', 'bold',)).pack()
 iceCoffee1 = Button (icecoffeeWindow, text= "Ice Coffee size: Small 7.99", bg='White', fg='Black', 
                                font=('Times', '12', 'bold'), command = lambda: [end(), icecoffeeWindow.destroy()])
 icecoffee1.pack()
    
 iceCoffee2 = Button (icecoffeeWindow, text = "Ice Coffee size: Medium 8.49", bg = 'White', fg='Black', 
                                font=('Times', '12', 'bold'), command = lambda: [end(), icecoffeeWindow.destroy()])
 iceCoffee2.pack()                            
    
 iceCoffee3 = Button (icecoffeeWindow, text = "Ice Coffee size: Large 8.99", bg='White', fg='Black', 
                                font=('Times', '12', 'bold'), command = lambda: [end(), icecoffeeWindow.destroy()])
 iceCoffee3.pack()
    
    #After a user chooses their ice coffee option and pays, they are taken to the end of the window and are given their beverage 

def end(): #The last window thanks the customer for their purchase
    global endlabel
    endWindow = Toplevel()
    endWindow.title('Thank you for your purchase')
    endWindow.geometry('400x450')

    endlabel = Label(endWindow, text = "Thank you for your Purchase!", font=("Times", "18", "bold",))
    endlabel.pack()

end()

    
 
