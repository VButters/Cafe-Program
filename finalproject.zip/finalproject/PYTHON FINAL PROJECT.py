'''
Cafe Program
Veronica Butters 
v2.0
5/11/2023
'''

import tkinter as tk
from tkinter import *
from tkinter import ttk
root = Tk()


def select (): #First window, users click whether they want hot coffee, ice coffee, or hot chocolate 
	global beverageSelection
	selectWindow = Toplevel()
	selectWindow.title('Beverage Selection')
	selectWindow.geometry('400x150')
	beverageSelection = Label(selectWindow, text = 'Please select which beverage you want : ',
                        font =('Times', '18', 'bold')).pack()
	beverageSelection1 = Button(selectWindow, text = "hot chocolate", bg ='White', fg='Black',
																	font=('Times', '12', 'bold'), command = lambda: [hotChocolate(), selectWindow.destroy()])
	beverageSelection1.pack()
						
	beverageSelection2 = Button(selectWindow, text = "hot coffee", bg='White', fg='Black',
																	font=('Times', '12', 'bold'), command = lambda: [hotCoffee(), selectWindow.destroy()])
	beverageSelection2.pack()
						
	beverageSelection3 = Button(selectWindow, text = "ice coffee", bg='White', fg='Black',
                                                                        font=('Times', '12', 'bold'), command = lambda: [iceCoffee(), selectWindow.destroy()])
	beverageSelection3.pack()
    #After the users choose one of the two options, it leads them to a second window 	

def hotChocolate(): #Window user clicks Hot Chocolate, the user chooses whether they want a small, medium, or large
    global hotChocolatelabel
    hotChocolateWindow = Toplevel()
    hotChocolateWindow.title ('Hot Chocolate Sizes') 
    hotChocolateWindow.geometry('400x150')
        
    hotChocolatelabel = Label (hotChocolateWindow, text = 'Please select a size :',
                            font=('Times', '18', 'bold',)).pack()
    hotChocolate1 = Button(hotChocolateWindow, text='small', bg ='White', fg='Black' ,
                                                   font=('Times', '12', 'bold'),command = lambda: [end(), hotChocolateWindow.destroy()])
    hotChocolate1.pack()
        
    hotChocolate2 = Button(hotChocolateWindow, text ='medium', bg='White', fg='Black', 
                                                   font=('Times', '12', 'bold'),command = lambda: [end(), hotChocolateWindow.destroy()])
    hotChocolate2.pack()
        
    hotChocolate3 = Button(hotChocolateWindow, text = 'large', bg= 'White', fg ='Black',
                                                   font=('Times', '12', 'bold'),command = lambda: [end(), hotChocolateWindow.destroy()])  
    hotChocolate3.pack()
        
    #After the user chooses a size, it showcases their prices and they have to pay
    
def hotChocolateprices(): #Window where the user clicks to purchase their Hot Chocolate, prices vary based on sizing
   global hotChocolatelabel
   hotChocolateWindow = Toplevel()
   hotChocolateWindow.title ('Hot Chocolate Prices') 
   hotChocolateWindow.geometry('400x150')
   
   hotChocolatelabel = Label (hotchocolateWindow, text = 'Payment : ',
                        font=('Times', '18', 'bold',)).pack()
   hotChocolateprice1 = Button(hotchocolateWindow, text= "Hot Chocolate size: Small 6.99", bg='White', fg='Black',
                                 font=('Times', '12', 'bold'),command = lambda: [end(),hotChocolateWindow.quit()])
   hotChocolateprice1.pack()
    
   hotChocolateprice2 = Button(hotchocolateWindow, text = "Hot Chocolate size: Medium 7.49", bg = 'White', fg='Black',
                                 font=('Times', '12', 'bold'),command = lambda: [end(),hotChocolateWindow.quit()])
   hotChocolateprice2.pack()                            
    
   hotChocolateprice3 = Button(hotchocolateWindow, text = "Hot Chocolate size: Large 7.99", bg='White', fg='Black', 
                                 font=('Times', '12', 'bold'),command = lambda: [end(),hotChocolateWindow.quit()])
   hotChocolateprice3.pack()
    
    #After a user chooses their hot chocolate option and pays, they are taken to the end of the window and are given their beverage
   
def hotCoffee():  #Window user clicks Hot Coffee, the user chooses whether they want a small, medium, or large
 global hotcoffeelabel
 hotCoffeeWindow = Toplevel()
 hotCoffeeWindow.title ('Hot Coffee Sizes') 
 hotCoffeeWindow.geometry('400x150')
        
 hotcoffeelabel = Label(hotCoffeeWindow, text = 'Please select a size :',
                            font=('Times', '18', 'bold',)).pack()
 hotCoffeeprice1 = Button(hotCoffeeWindow, text='small', bg ='White', fg='Black', 
                             font=('Times', '12', 'bold'),command = lambda: [end(),hotCoffeeWindow.destroy()])
 hotCoffeeprice1.pack()
        
 hotCoffeeprice2 = Button(hotCoffeeWindow, text ='medium', bg='White', fg='Black', 
                             font=('Times', '12', 'bold'),command = lambda: [end(),hotCoffeeWindow.destroy()])
 hotCoffeeprice2.pack()
        
 hotCoffeeprice3 = Button(hotCoffeeWindow, text = 'large', bg= 'White', fg ='Black',
                             font=('Times', '12', 'bold'),command = lambda: [end(),hotCoffeeWindow.destroy()])
 hotCoffeeprice3.pack()

    #After the user chooses a size, it showcases their prices and they have to pay
    
def hotCoffeeeprices(): #Window where the user clicks to purchase their Hot Chocolate, prices vary based on sizing
 global hotCoffeeelabel
 hotCoffeeWindow = TopLevel()
 hoCoffeeWindow.title ('Hot Coffee Prices') 
 hotCoffeeWindow.geometry('400x150')
   
 hotCoffeelabel = Label(hotcoffeeWindow, text = 'Payment : ',
                     font=('Times', '18', 'bold',)).pack()
 hotCoffee1 = Button(hotcoffeeWindow, text= "Hot Coffee size: Small 7.99", bg='White', fg='Black',
                            font=('Times', '12', 'bold'),command = lambda: [end(),hotCoffeeWindow.quit()])
 hotCoffee1.pack()
    
 hotCoffee2 = Button(hotcoffeeWindow, text = "Hot Coffee size: Medium 8.49", bg = 'White', fg='Black', 
                             font=('Times', '12', 'bold'),command = lambda: [end(),hotCoffeeWindow.quit()])
 hotCoffee2.pack()                            
    
 hotCoffee3 = Button(hotcoffeeWindow, text = "Hot Coffee size: Large 8.99", bg='Whote', fg='Black', 
                            font=('Times', '12', 'bold'),command = lambda: [end(),hotCoffeeWindow.quit()])
 hotCoffee3.pack()
    
    #After a user chooses their hot coffee option and pays, they are taken to the end of the window and are given their beverage 
  
def iceCoffee():  #Window user clicks Ice Coffee, the user chooses whether they want a small, medium, or large
 global icecoffeelabel
 iceCoffeeWindow = Toplevel()
 iceCoffeeWindow.title ('Ice Coffee Sizes') 
 iceCoffeeWindow.geometry('400x150')
        
 iceCoffeelabel = Label(iceCoffeeWindow, text = 'Please select a size :',
                            font=('Times', '18', 'bold',)).pack()
 iceCoffee1 = Button(iceCoffeeWindow, text='small', bg ='White', fg='Black', 
                                                   font=('Times', '12', 'bold'),command = lambda: [end(),iceCoffeeWindow.destroy()])
 iceCoffee1.pack()
        
 iceCoffee2 = Button(iceCoffeeWindow, text ='medium', bg='White', fg='Black', 
                                                   font=('Times', '12', 'bold'),command = lambda: [end(),iceCoffeeWindow.destroy()])
 iceCoffee2.pack()
        
 iceCoffee3 = Button(iceCoffeeWindow, text = 'large', bg= 'White', fg ='Black',
                                                   font=('Times', '12', 'bold'),command = lambda: [end(),iceCoffeeWindow.destroy()])
 iceCoffee3.pack()
    #After the user chooses a size, it showcases their prices
 
 def iceCoffeeprices(): #Window where the user has to purchase their Ice Coffee, prices vary based on sizing
  global icecoffeelabel
 iceCoffeeWindow = Toplevel()
 iceCoffeeWindow.title ('Ice Coffee Prices') 
 iceCoffeeWindow.geometry('400x150')
   
 iceCoffeelabel = Label(iceCoffeeWindow, text = 'Payment : ',
                   font=('Times', '18', 'bold',)).pack()
 iceCoffeeprice1 = Button(iceCoffeeWindow, text= "Ice Coffee size: Small 7.99", bg='White', fg='Black', 
                                 font=('Times', '12', 'bold'),command = lambda: [end(),iceCoffeeWindow.quit()])
 iceCoffeeprice1.pack()
    
 iceCoffeeprice2 = Button(iceCoffeeWindow, text = "Ice Coffee size: Medium 8.49", bg = 'White', fg='Black', 
                                 font=('Times', '12', 'bold'),command = lambda: [end(),iceCoffeeWindow.quit()])
 iceCoffeeprice2.pack()                            
    
 iceCoffeeprice3 = Button(iceCoffeeWindow, text = "Ice Coffee size: Large 8.99", bg='White', fg='Black', 
                                 font=('Times', '12', 'bold'),command = lambda: [end(),iceCoffeeWindow.quit()])
 iceCoffeeprice3.pack()
    
    #After a user chooses their ice coffee option and pays, they are taken to the end. 

def end():
    global endlabel
    endWindow = Toplevel()
    endWindow.title('Thank you for your purchase')
    endWindow.geometry('600x395')

    endlabel = Label(endWindow, text="Thank you for your Purchase!", font=("Times", "18", "bold"))
    endlabel.pack()
    
    beverages = PhotoImage(file="beverages.png")
    logo = Label(endWindow, image=beverages)
    logo.pack()
    
    end = Button(endWindow, text='Exit', bg='white', fg='black', font=('Times', '12', 'bold'), command=lambda: root.destroy())
    end.pack()

    endWindow.mainloop()

    
    
root.title('Cafe Program')
root.geometry('700x595')

#the first window
welcome = Label(root,
        text='Welcome to the Cafe',
        font=("Times", "24", "bold")
        ).pack()
        
beverages=PhotoImage(file="threebeverages.png")
logo=Label(root, image=beverages).pack()

#button that starts program
btn = Button(root, text='Enter', bg='White', fg='Black',
                                font=('Times', '12', 'bold'), command=lambda: [select(), root.withdraw()])
btn.pack()

root.mainloop()

    
 
